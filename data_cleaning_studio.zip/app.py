"""
Automated Data Cleaning Studio — Streamlit App
================================================
Upload a messy CSV, choose cleaning options, preview before/after,
and download the cleaned file.

Run with:
    streamlit run app.py
"""

import io
import json

import numpy as np
import pandas as pd
import streamlit as st

from cleaning_engine import clean_dataframe

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Data Cleaning Studio",
    page_icon="🧹",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Styling ───────────────────────────────────────────────────────────────────
st.markdown("""
<style>
.metric-card {
    background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px;
    padding: 14px 18px; text-align: center;
}
.metric-card .num { font-size: 1.6rem; font-weight: 700; color: #1e293b; }
.metric-card .lbl { font-size: 0.8rem; color: #64748b; text-transform: uppercase; letter-spacing: 0.05em; }
.action-pill {
    display: inline-block; background: #eef2ff; color: #4338ca;
    border-radius: 999px; padding: 3px 10px; font-size: 0.8rem; margin: 2px;
}
.section-header { font-size: 1.05rem; font-weight: 600; color: #1e293b; margin: 0.5rem 0; }
</style>
""", unsafe_allow_html=True)

st.title("🧹 Automated Data Cleaning Studio")
st.caption("Upload a CSV → automatic type detection, deduplication, missing-value & outlier handling → download a clean dataset.")
st.divider()


# ── Sidebar: cleaning options ───────────────────────────────────────────────────
with st.sidebar:
    st.header("⚙️ Cleaning Options")

    st.markdown("**Missing values**")
    numeric_strategy = st.selectbox(
        "Numeric columns",
        ["median", "mean", "zero"],
        help="How to fill missing numeric values."
    )
    categorical_strategy = st.selectbox(
        "Categorical / text columns",
        ["mode", "missing_label"],
        help="'mode' fills with the most frequent value; 'missing_label' fills with the literal text 'Missing'."
    )

    st.markdown("**Outliers (numeric columns)**")
    outlier_method = st.selectbox(
        "Outlier strategy",
        ["cap", "remove", "none"],
        format_func=lambda x: {
            "cap": "Cap to IQR bounds (winsorize)",
            "remove": "Remove rows with outliers",
            "none": "Detect only — don't modify",
        }[x],
    )
    iqr_multiplier = st.slider(
        "IQR multiplier (sensitivity)", 1.0, 3.0, 1.5, 0.1,
        help="Lower = more aggressive outlier detection. 1.5 is the standard statistical convention."
    )

    st.divider()
    st.caption(
        "**Pipeline order:**\n"
        "1. Standardize column names\n"
        "2. Trim whitespace\n"
        "3. Remove duplicate rows\n"
        "4. Auto-detect & convert types\n"
        "5. Handle missing values\n"
        "6. Handle outliers"
    )


# ── Helpers ───────────────────────────────────────────────────────────────────
@st.cache_data
def load_csv(file) -> pd.DataFrame:
    return pd.read_csv(file)


def df_to_csv_bytes(df: pd.DataFrame) -> bytes:
    buf = io.StringIO()
    df.to_csv(buf, index=False)
    return buf.getvalue().encode("utf-8")


def dtype_summary(df: pd.DataFrame) -> pd.DataFrame:
    summary = pd.DataFrame({
        "column": df.columns,
        "dtype": [str(t) for t in df.dtypes],
        "missing": df.isna().sum().values,
        "missing_%": (df.isna().mean() * 100).round(1).values,
        "unique": [df[c].nunique() for c in df.columns],
    })
    return summary


# ── File upload ───────────────────────────────────────────────────────────────
uploaded_file = st.file_uploader("Upload a CSV file", type=["csv"])

if uploaded_file is None:
    st.info("👆 Upload a CSV to get started. The app will automatically detect column types, "
            "clean text, remove duplicates, handle missing values, and treat outliers.")
    st.markdown("### What this app does")
    c1, c2, c3 = st.columns(3)
    with c1:
        st.markdown("**🔍 Smart Type Detection**")
        st.write("Columns stored as text (e.g. `\"$50,000\"`, `\"2021-01-15\"`, `\"Yes\"/\"No\"`) "
                 "are automatically converted to numeric, datetime, boolean, or category types.")
    with c2:
        st.markdown("**🧼 Cleaning**")
        st.write("Column names are standardized to `snake_case`, whitespace is trimmed, "
                 "and exact duplicate rows are removed.")
    with c3:
        st.markdown("**📊 Missing Values & Outliers**")
        st.write("Missing values are imputed based on column type (median/mode/interpolation). "
                 "Outliers are detected via the IQR method and capped or removed.")

else:
    raw_df = load_csv(uploaded_file)

    st.markdown('<div class="section-header">📄 Original Data Preview</div>', unsafe_allow_html=True)
    st.dataframe(raw_df.head(10), use_container_width=True)

    with st.expander("Original column types & missing values"):
        st.dataframe(dtype_summary(raw_df), use_container_width=True)

    st.divider()

    # ── Run cleaning ──
    with st.spinner("Cleaning your data..."):
        cleaned_df, report = clean_dataframe(
            raw_df,
            numeric_strategy=numeric_strategy,
            categorical_strategy=categorical_strategy,
            outlier_method=outlier_method,
            iqr_multiplier=iqr_multiplier,
        )

    st.success("✅ Cleaning complete!")

    # ── Summary metrics ──
    m1, m2, m3, m4 = st.columns(4)
    with m1:
        st.markdown(f'<div class="metric-card"><div class="num">{report["original_shape"][0]:,}</div>'
                    f'<div class="lbl">Original Rows</div></div>', unsafe_allow_html=True)
    with m2:
        st.markdown(f'<div class="metric-card"><div class="num">{report["final_shape"][0]:,}</div>'
                    f'<div class="lbl">Final Rows</div></div>', unsafe_allow_html=True)
    with m3:
        st.markdown(f'<div class="metric-card"><div class="num">{report["duplicates_removed"]:,}</div>'
                    f'<div class="lbl">Duplicates Removed</div></div>', unsafe_allow_html=True)
    with m4:
        n_type_changes = sum(
            1 for v in report["type_conversions"].values()
            if "already" not in v.get("note", "") and "free text" not in v.get("note", "")
        )
        st.markdown(f'<div class="metric-card"><div class="num">{n_type_changes}</div>'
                    f'<div class="lbl">Columns Retyped</div></div>', unsafe_allow_html=True)

    st.markdown("")

    # ── Tabs for detailed report ──
    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "🧾 Cleaned Preview", "🔄 Type Conversions", "❓ Missing Values",
        "📈 Outliers", "🏷️ Column Renames"
    ])

    with tab1:
        st.dataframe(cleaned_df.head(20), use_container_width=True)
        st.caption(f"Showing first 20 of {len(cleaned_df):,} rows.")
        st.dataframe(dtype_summary(cleaned_df), use_container_width=True)

    with tab2:
        if report["type_conversions"]:
            rows = []
            for col, info in report["type_conversions"].items():
                rows.append({
                    "column": col,
                    "original_type": info["original"],
                    "new_type": info["converted_to"],
                    "detail": info["note"],
                })
            conv_df = pd.DataFrame(rows)
            # Highlight actual conversions
            changed = conv_df[~conv_df["detail"].str.contains("already|free text", regex=True)]
            unchanged = conv_df[conv_df["detail"].str.contains("already|free text", regex=True)]
            if len(changed):
                st.markdown("**✨ Columns automatically converted:**")
                st.dataframe(changed, use_container_width=True, hide_index=True)
            if len(unchanged):
                with st.expander(f"Unchanged columns ({len(unchanged)})"):
                    st.dataframe(unchanged, use_container_width=True, hide_index=True)
        else:
            st.write("No columns needed type conversion.")

    with tab3:
        if report["missing_values"]:
            rows = [{"column": c, **v} for c, v in report["missing_values"].items()]
            st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
        else:
            st.write("No missing values found. 🎉")

    with tab4:
        if report["outliers"]:
            rows = []
            for c, v in report["outliers"].items():
                rows.append({
                    "column": c,
                    "n_outliers": v["n_outliers"],
                    "lower_bound": v["bounds"][0],
                    "upper_bound": v["bounds"][1],
                    "action": v["action"],
                })
            st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
            st.caption(f"Outliers detected via IQR method (multiplier = {iqr_multiplier}).")
        else:
            st.write("No outliers detected in numeric columns. 🎉")

    with tab5:
        if report["column_renames"]:
            rows = [{"original_name": k, "standardized_name": v}
                   for k, v in report["column_renames"].items() if k != v]
            if rows:
                st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
            else:
                st.write("All column names were already standardized.")

    st.divider()

    # ── Download ──
    st.markdown('<div class="section-header">⬇️ Download Cleaned Dataset</div>', unsafe_allow_html=True)
    csv_bytes = df_to_csv_bytes(cleaned_df)
    st.download_button(
        label="📥 Download Cleaned CSV",
        data=csv_bytes,
        file_name=f"cleaned_{uploaded_file.name}",
        mime="text/csv",
        use_container_width=True,
        type="primary",
    )

    with st.expander("📋 Full cleaning report (JSON)"):
        def _default(o):
            if isinstance(o, (np.integer,)):
                return int(o)
            if isinstance(o, (np.floating,)):
                return float(o)
            if isinstance(o, (pd.Timestamp,)):
                return str(o)
            return str(o)
        st.json(json.loads(json.dumps(report, default=_default)))
