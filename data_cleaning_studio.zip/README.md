# 🧹 Automated Data Cleaning Studio

A Streamlit web app that takes a messy CSV and returns a cleaned,
properly-typed, download-ready version — with a full transparency
report of every change made.

---

## Quickstart

```bash
pip install -r requirements.txt
streamlit run app.py
```

Opens at `http://localhost:8501`. Upload `sample_messy_data.csv` to see
a worked example.

---

## What it does

### 1. Column name standardization
`  Employee Name  ` → `employee_name`
`Salary ($)` → `salary`
`Is Active?` → `is_active`

Lowercase, snake_case, special characters stripped, whitespace collapsed,
duplicate names auto-numbered.

### 2. Whitespace & text normalization
Trims leading/trailing spaces and collapses internal multi-spaces
in every text column (`"  good  "` → `"good"`).

### 3. Duplicate removal
Drops exact duplicate rows.

### 4. Smart type detection & conversion
For every text/object column, tries — in order:

| Step | Detects | Example |
|---|---|---|
| Numeric | Currency, percent, comma-formatted numbers, accounting negatives | `"$50,000"` → `50000.0`, `"(20000)"` → `-20000.0` |
| Datetime | Mixed date formats in the same column | `"2021-01-15"`, `"01/20/2021"`, `"March 5, 2022"` → `datetime64` |
| Boolean | Yes/No, True/False, Y/N, 1/0 | `"Yes"`/`"No"` → `True`/`False` |
| Category | Low-cardinality text (≤50 unique, ≤50% of rows) | `"Sales"`, `"IT"`, `"HR"` → `category` dtype |
| Text | Everything else | kept as string |

A column converts only if **≥80%** of its non-null values parse successfully —
this avoids corrupting genuinely mixed-content columns.

### 5. Missing value handling
- **Numeric** → median (default), mean, or zero
- **Datetime** → linear interpolation + forward/back fill
- **Boolean** → mode (most frequent value)
- **Categorical/text** → mode, or literal `"Missing"` label
- **Columns >60% missing** → dropped entirely

### 6. Outlier handling (IQR method)
For numeric columns (excluding binary 0/1 flags):
- **Cap (winsorize)** — clip to `[Q1 - k×IQR, Q3 + k×IQR]` (default, k=1.5)
- **Remove** — drop rows containing outliers
- **None** — detect only, report without modifying

---

## Output

- Side-by-side before/after preview
- Tabbed report: type conversions, missing-value actions, outlier bounds, column renames
- One-click **Download Cleaned CSV** button
- Full JSON cleaning report (expandable)

---

## Files

```
data_cleaner/
├── app.py                  # Streamlit UI
├── cleaning_engine.py       # Pure-logic cleaning pipeline (no Streamlit deps)
├── requirements.txt
├── sample_messy_data.csv    # Test file
└── README.md
```

`cleaning_engine.py` can also be imported and used standalone:

```python
import pandas as pd
from cleaning_engine import clean_dataframe

df = pd.read_csv("my_data.csv")
cleaned_df, report = clean_dataframe(df)
```
